//shai
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SignatureException;
import java.util.Formatter;
import java.util.Scanner;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public class hmacshal {
    private static String toHexString(byte[] bytes) {
        Formatter formatter = new Formatter();
        for (byte b : bytes) {
            formatter.format("%02x", b);
        }
        return formatter.toString();
    }

    public static String calculate(String data, String key)
            throws SignatureException, NoSuchAlgorithmException, InvalidKeyException {
        SecretKeySpec signingeKey = new SecretKeySpec(key.getBytes(), "HmacSHA1");
        Mac mac = Mac.getInstance("HmacSHA1");
        mac.init(signingeKey);
        return toHexString(mac.doFinal(data.getBytes()));
    }

    public static void main(String[] args) throws SignatureException, NoSuchAlgorithmException, InvalidKeyException {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter data to encrypte: ");
        String data = sc.nextLine();
        System.out.println("Enter key to encryption : ");
        String key = sc.nextLine();
        String mdigest = calculate(data, key);
        System.out.println("Message Digest / Hash Value after applying HMAC_SHAI : " + mdigest);

    }
}
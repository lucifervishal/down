//Railfence
import java.util.Scanner;

public class RailFence {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter plain text: ");
        String plainText = sc.nextLine();
        System.out.println("Enter the depth: ");
        int key = sc.nextInt();
        String en = encryption(plainText, key);
        System.out.println("\n Encrypted Message: " + en);
        System.out.println("\n Decrypted Message: " + decryption(en, key));
    }

    static String encryption(String text, int key) {
        String encryptedText = "";
        boolean check = false;
        int i, j, k = 0, row = key, col = text.length();
        char[][] a = new char[row][col];
        for (j = 0; j < col; j++) {
            if (k == 0 || k == key - 1) {
                check = !check;
            }
            a[k][j] = text.charAt(j);
            if (check)
                k++;
            else
                k--;
        }
        for (i = 0; i < row; i++) {
            for (j = 0; j < col; j++) {
                System.out.print(a[i][j] + "");
            }
            System.out.println();
        }
        for (i = 0; i < row; i++) {
            for (j = 0; j < col; j++) {
                if (a[i][j] != 0)
                    encryptedText += a[i][j];
            }
        }
        return encryptedText;
    }

    static String decryption(String text, int key) {
        String decryptedText = "";
        boolean check = false;
        int i = 0, j, row = key, col = text.length();
        char[][] a = new char[row][col];
        for (j = 0; j < col; j++) {
            if (i == 0 || i == key - 1) {
                check = !check;
            }
            a[i][j] = '*';
            if (check)
                i++;
            else
                i--;
        }
        int index = 0;
        check = false;
        for (i = 0; i < row; i++) {
            for (j = 0; j < col; j++) {
                if (a[i][j] == '*' && index < col) {
                    a[i][j] = text.charAt(index++);
                }
            }
        }
        i = 0;
        for (j = 0; j < col; j++) {
            if (i == 0 || i == key - 1) {
                check = !check;
            }
            decryptedText += a[i][j];
            if (check)
                i++;
            else
                i--;
        }
        return decryptedText;
    }
}

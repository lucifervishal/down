//DES
import java.util.*;
import javax.crypto.*;
import javax.crypto.spec.*;
import java.io.*;
import java.security.*;
import java.security.spec.*;

public class Des {
    public static void main(String[] args) throws IOException,
            NoSuchAlgorithmException, InvalidKeyException, InvalidKeySpecException,
            NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException {
        Scanner sc = new Scanner(System.in);
        String line = System.getProperty("line.separator");
        sc.useDelimiter("\n");
        // String we want to encrypt
        System.out.print("Enter string for encryption : ");
        String message = sc.next();
        byte[] myMessage = message.getBytes();
        // Generating key
        KeyGenerator Mygenerator = KeyGenerator.getInstance("DES");
        SecretKey myDesKey = Mygenerator.generateKey();
        // Initializing crypto algorithm
        Cipher myCipher = Cipher.getInstance("DES");
        // setting encrytion mode
        myCipher.init(Cipher.ENCRYPT_MODE, myDesKey);
        byte[] myEncryptedBytes = myCipher.doFinal(myMessage);
        // setting decrytion mode
        myCipher.init(Cipher.DECRYPT_MODE, myDesKey);
        byte[] myDecryptedBytes = myCipher.doFinal(myEncryptedBytes);
        String encrypteddata = new String(myEncryptedBytes);
        String decrypteddata = new String(myDecryptedBytes);
        System.out.println("\nMessage : " + message + "\n");
        System.out.println("Encrypted - " + encrypteddata + "\n");
        System.out.println("Decrypted - " + decrypteddata + "\n");
    }
}
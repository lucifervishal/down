import java.io.*;
import java.util.*;

public class Ceaser_cipher{
    public static final String aplha = "abcdefghijklmnopqrstuvwxyz";

    public static String encrypt(String mssg, int shift_key){
        mssg = mssg.toLowerCase();
        String cipher_text = "";
        for (int i=0; i<mssg.length();i++){
            int char_pos = aplha.indexOf(mssg.charAt(i));
            int key_value = (shift_key + char_pos) % 26;
            char replace_val = aplha.charAt(key_value);
            cipher_text+=replace_val;
        }
        return cipher_text;

    }

    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        String mssg;
        int key=0;

        System.out.println("Enter the string for encryption: ");
        mssg = sc.next();
        
        System.out.println("\n \nEnter the Shift Key: ");
        key = sc.nextInt();

        System.out.println("\nEncryption Message: " + encrypt(mssg, key));

    }
}